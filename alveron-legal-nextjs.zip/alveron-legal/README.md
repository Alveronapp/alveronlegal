# Alveron Legal - Next.js Starter

This is a minimal Next.js starter for *Alveron Legal* prepared for easy upload to GitHub and 1-click deploy on Vercel.

How to use:
1. Download and unzip.
2. Upload contents to a new GitHub repository (drag & drop in the repo 'Upload files' UI).
3. Connect repo to Vercel and deploy.

Note: Install dependencies with `npm install` (or `pnpm`/`yarn`) if running locally.
