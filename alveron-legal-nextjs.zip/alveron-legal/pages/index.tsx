import { useState } from 'react'
import { motion } from 'framer-motion'

export default function Home() {
  const [query, setQuery] = useState('')
  const [responses, setResponses] = useState<string[]>([])

  const handleSearch = () => {
    if (query.trim() === '') return
    setResponses(prev => [
      `Result for: "${query}" — (demo response, will connect to backend later)`,
      ...prev
    ])
    setQuery('')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-6 font-sans">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-3xl font-bold text-blue-600 mb-6"
      >
        ⚖️ Alveron Legal
      </motion.h1>

      <div className="w-full max-w-xl">
        <div className="bg-white p-4 rounded-2xl shadow-md border">
          <div style={{display: 'flex', gap: 8}}>
            <input
              placeholder="Ask about legal cases, ADR, or land disputes..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              style={{flex: 1, padding: 10, borderRadius: 8, border: '1px solid #e5e7eb'}}
            />
            <button onClick={handleSearch} style={{padding: '10px 16px', borderRadius:8, background:'#2563eb', color:'white', border:'none'}}>
              Search
            </button>
          </div>
        </div>

        <div style={{marginTop: 18}}>
          {responses.map((res, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} style={{padding:12, background:'white', borderRadius:12, boxShadow:'0 4px 12px rgba(0,0,0,0.06)', marginBottom:10}}>
              {res}
            </motion.div>
          ))}
        </div>
      </div>
      <footer style={{marginTop: 30, opacity: 0.7}}>Built with ❤️ — Alveron Legal</footer>
    </div>
  )
}
